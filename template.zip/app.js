function validateForm(){
    const name = document.getElementById('name')
    const email = document.getElementById('email')
    const message = document.getElementById('message')
    if(name.value == ""){
        alert("Please fill all the details")
        return false
    }else if(email.value == ""){
        alert("Please fill all the details")
        return false
    }else{
        return true
    }
}

// function Ham(){
//     let ham = document.getElementById('show-ham')
//     ham.onclick((e)=>{
//         let menu = document.getElementById('nav').style
//         menu.display = "block"
//     })
// }

// function Ham(){
//     let menu = document.getElementById('nav').style
//     menu.display = "none"
// }
// let menu = document.getElementById('nav').addEventListener('click',()=>{
//     let x = document.getElementById('nav')
//     x.classList.toggle("remove")
// })





// window.onscroll = function(){
//     stickyNav()
//     let navbar = document.getElementsByClassName('nav')
// let sticky = navbar.offsetTop;
// function stickyNav(){
//     if(window.pageYOffset >=sticky){
//         navbar.classList.add('sticky')
//     }else{
//         navbar.classList.remove('sticky')
//     }
// }
// }


// const text = document.querySelector(".fancy")
// const string = text.textContent
// const letters = string.split("")
// text.textContent = ""

// for(let i = 0; i<letters.length; i++){
//     text.innerHTML += "<span>" + letters[i] + "</span>"
// }

// let char = 0;
// let timer = setInterval(() => {
//     const span = text.querySelectorAll('span')[char]
//     span.classList.add('fade')
//     char++
//     if(char===letters.length){
//         complete(()=>{
//             clearInterval(timer)
//             timer = null
//         })
//         return
//     }
// }, 50);